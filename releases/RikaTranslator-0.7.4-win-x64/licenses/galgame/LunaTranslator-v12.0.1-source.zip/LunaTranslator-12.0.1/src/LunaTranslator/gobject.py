import platform, os, sys
from ctypes import c_void_p

thisuserconfig = "userconfig"
runtime_bit_64 = platform.architecture()[0] == "64bit"


class unique_ptr(c_void_p):
    def __init__(self, ptr, deleter):
        super().__init__(ptr)
        self.deleter = deleter

    def release(self):
        ptr = self.value
        self.deleter = None
        c_void_p.__init__(self, None)
        return ptr

    def __del__(self):
        if self and self.deleter:
            self.deleter(self)


def GetDllpath(_, base=None):

    if base is None:
        base = os.path.abspath("files/DLL" + ("32", "64")[runtime_bit_64])
    if isinstance(_, str):
        return os.path.join(base, _)
    elif isinstance(_, (list, tuple)):
        return os.path.join(base, _[runtime_bit_64])


def __getdir(name="", basedir="cache"):

    fd = os.path.dirname(name)
    fn = os.path.basename(name)
    fn1 = os.path.abspath(basedir)
    fn1 = os.path.join(fn1, fd)
    os.makedirs(fn1, exist_ok=True)
    fn1 = os.path.join(fn1, fn)
    return fn1


def getcachedir(name=""):
    return __getdir(name)


def getconfig(name):
    return __getdir(name, thisuserconfig)


def gettempdir_1():
    tgt = __getdir("temp")
    return tgt


def gettempdir(filename=""):
    tgt = __getdir(os.path.join("temp", str(os.getpid()), filename))
    return tgt


try:
    TYPE_CHECKING = False
    from typing import TYPE_CHECKING
except:
    pass
if TYPE_CHECKING:
    from LunaTranslator import BASEOBJECT
base: "BASEOBJECT" = None
isRunningMutex = None
isRunningAlreadyExists = False
serverindex = 0
serverindex2 = 0
tempconfig = {}


class Consts:
    linkcolor = "#E91E63"

    class btncolor:
        class light:
            class enabled:
                back = "#FF69B4"
                center = "white"

            class disabled:
                back = "transparent"
                center = "#5D5D5D"

        class dark:
            class enabled:
                back = "#FF69B4"
                center = "black"

            class disabled:
                back = "transparent"
                center = "#CDCED1"

    btnscale = 1.2
    toolwdivh = 4 / 3
    toolscale = 1.5
    IconSizeHW = 1.1


runtime_for_xp = tuple(sys.version_info)[:2] == (3, 4)
runtime_for_win10 = tuple(sys.version_info)[:2] >= (3, 9)

if runtime_for_win10:
    runtimedir = "runtime3.13-64"
elif runtime_for_xp:
    runtimedir = "runtime3.4-32"
elif runtime_bit_64:
    runtimedir = "runtime3.7-64"
else:
    runtimedir = "runtime3.7-32"

runtimedir = os.path.join("files", runtimedir)
platformversion = tuple(int(_) for _ in platform.version().split("."))
sys_le_xp = platformversion[0] <= 5
sys_ge_win_11 = platformversion[2] >= 22000  # 21h2
sys_ge_win_10 = platformversion[0] >= 10
sys_ge_win8 = platformversion[:2] >= (6, 2)
sys_le_win7 = platformversion[:2] <= (6, 1)
sys_le_win81 = platformversion[0] <= 6
# https://learn.microsoft.com/en-us/windows/release-health/release-information
sys_win10_release_supported = platformversion[2] >= 17134  # 1803


def is_running_on_wine():
    import ctypes
    from ctypes import wintypes

    kernel32 = ctypes.WinDLL("kernel32.dll", use_last_error=False)
    GetModuleHandleW = kernel32.GetModuleHandleW
    GetModuleHandleW.argtypes = [wintypes.LPCWSTR]
    GetModuleHandleW.restype = wintypes.HMODULE
    hmodule = GetModuleHandleW("ntdll.dll")
    if hmodule == 0:
        return False
    GetProcAddress = kernel32.GetProcAddress
    GetProcAddress.argtypes = [wintypes.HMODULE, wintypes.LPCSTR]
    func_addr = GetProcAddress(hmodule, b"wine_get_version")

    return func_addr is not None and func_addr != 0

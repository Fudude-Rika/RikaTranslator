from translator.basetranslator import basetrans
from myutils.config import _TR
import os
from language import Languages
from LunaSubProcess import LunaSubProcess


class TS(basetrans):
    def init(self):
        self.path11 = None
        self.pair = None
        self.checkpath()

    def checkpath(self):

        pairs = (self.srclang, self.tgtlang)
        if self.config["path"] != self.path11 or pairs != self.pair:

            self.path11 = self.config["path"]
            base = os.path.abspath(
                os.path.join(self.config["path"], "GTS/" + self.srclang + self.tgtlang)
            )
            if not os.path.isdir(base):
                return False
            dll = None
            for f in os.listdir(base):
                if f.split(".")[-1] == "dll":
                    dll = f
                    break
            if dll is None:
                return False
            self.pair = pairs
            self.path = os.path.join(base, dll)
            self.path2 = os.path.join(base, "DCT")
            self._proc = LunaSubProcess.kingsoft(self.path, self.path2)
        return True

    def translate(self, content: str):
        if not self.checkpath():
            raise Exception(_TR("翻译器加载失败"))
        return self._proc.translate(content)

    def langmap(self):
        return {
            Languages.Chinese: "SChinese",
            Languages.TradChinese: "TChinese",
            Languages.English: "English",
            Languages.Japanese: "Japanese",
            Languages.Auto: "Japanese",
        }

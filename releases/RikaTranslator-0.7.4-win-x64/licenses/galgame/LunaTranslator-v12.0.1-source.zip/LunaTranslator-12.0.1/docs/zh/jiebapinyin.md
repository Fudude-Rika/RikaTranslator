# 中文分词及注音

1. ## 下载依赖库并解压
    
    下载[中文分词器和拼音转换器](https://lunatranslator.org/Resource/otherresource/jiebapinyin)，将内容解压到软件的**根目录**或**LunaTranslator目录**或**配置文件目录(userconfig)** 中。


1. ## 切换语言

    切换源语言为**简体中文**或**繁体中文**

1. ## 最终效果

    ![img](https://image.lunatranslator.org/zh/jiebapinyin.png)


1. ## 添加中文->英文词典查词

    下载[shawkynasr/CC-CEDICT](https://github.com/shawkynasr/CC-CEDICT)，添加到**辞书**->**离线**->**MDict**即可。
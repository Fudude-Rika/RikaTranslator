# 大模型翻译接口

## 大模型通用接口

::: details 同时使用多个大模型接口？
如果只是有多个不同的密钥想要轮询，只需用|分割就可以了。

但有时想要同时使用多个不同的api接口地址/prompt/model/参数等来对比翻译效果。方法是：

1. 点击上方的“+”按钮，选择大模型通用接口
    ![img](https://image.lunatranslator.org/zh/damoxing/plus.png)
1. 弹出一个窗口，为之取个名字。这样会复制一份当前大模型通用接口的设置和api。
    ![img](https://image.lunatranslator.org/zh/damoxing/name.png)
1. 激活复制的接口，并可以进行单独设置。复制的接口可以和原接口一起运行，从而使用多个不同的设置来运行。
    ![img](https://image.lunatranslator.org/zh/damoxing/extraapi3.png)
:::

### 参数说明

1. #### API接口地址
 
    大部分常见大模型平台的`API接口地址`可以在下拉列表中选取，但可能会有遗漏。对于其他没有列举出来的接口，请自行查阅平台的文档来填写。
 
1. #### API Key

    `API Key`可以在平台获取。对于添加的多个Key，会自动进行轮询，并根据错误反馈调整Key的权重。

1. #### model

    大部分平台填写好`API接口地址`和`API Key`后，点击`model`旁的刷新按钮即可获取可用的模型列表。

    如果平台不支持拉取模型的接口，且默认列表中没有要用的模型，那么请参照接口官方文档手动填写模型。

1. #### 流式输出

    开启后，将以流式增量显示模型输出的内容，否则会在模型完整输出后一次性显示所有内容。


1. #### 附带上下文个数

    会附带若干条历史的原文和翻译接口提供给大模型，以优化翻译。设置为0将禁用此优化。


1. #### 自定义 system prompt / 自定义 user message / prefill {#anchor-prompt}

    几种不同的控制输出内容的手段，可以根据喜好设置，或者使用默认即可。

    自定义system prompt和user message中可以使用字段来引用一些信息：
    - `{sentence}`：当前欲翻译的文本
    - `{srclang}`和`{tgtlang}`：源语言和目标语言。如果prompt中仅使用英语，则会替换成语言名称的英语翻译，否则会替换成语言名称的当前UI语言翻译。
    - `{contextOriginal[N]}`和`{contextTranslation[N]}`和`{contextBoth[N]}`：N条历史原文、译文、两者。若输入是`contextBoth[N]`，则会引用`附带上下文个数`的值；若输入是`contextBoth[10]`，则会使用输入的10条数目。
    - `{DictWithPrompt[XXXXX]}`：此字段可以引用`专有名词翻译`中的词条，**且当没有匹配到的词条时，该字段会被清除以避免破坏翻译内容**。其中，`XXXXX`是一段引导LLM使用给定的词条来优化翻译的prompt，可以自行定义，或禁用自定义user message以使用默认的引导prompt。

1. #### Temperature / max tokens / top p / frequency penalty

    对于部分平台的部分模型，可能`top p`和`frequency penalty`等参数不被接口接受，或者`max tokens`参数被弃用并改为了`max completion tokens`，激活或取消开关可以解决这些问题。

1. #### reasoning effort

    部分平台支持的思考强度控制。

    对于Gemini平台，会自动将选项映射为Gemini的`thinkingBudget`，映射规则为：
    
    none/minimal->0(停用思考，但对于Gemini-2.5-Pro模型不适用), low->512, medium->-1（开启动态思维）, high/xhigh->24576。

1. #### thinking.type

    部分平台(主要是DeepSeek)支持的思考模式开关。

1. #### 其他参数

    以上只提供了一些常见的参数，如果使用的平台提供了其他未列出的有用的参数，可以自行添加键值。

## 常见的大模型平台

### 欧美的大模型平台

::: tabs

== OpenAI

**API Key** https://platform.openai.com/api-keys

== Gemini

**API Key** https://aistudio.google.com/app/apikey

== Nvidia

**API Key** https://build.nvidia.com/explore/discover

== claude

**API Key** https://console.anthropic.com/

**model**  https://docs.anthropic.com/en/docs/about-claude/models

== cohere

**API Key** https://dashboard.cohere.com/api-keys

== x.ai

**API Key** https://console.x.ai/

== groq

**API Key** https://console.groq.com/keys

== OpenRouter

**API Key** https://openrouter.ai/settings/keys


== Mistral AI

**API Key** https://console.mistral.ai/api-keys/

== Azure

**API接口地址** `https://{endpoint}.openai.azure.com/openai/deployments/{deployName}/chat/completions?api-version=2023-12-01-preview`

其中，将`{endpoint}`和`{deployName}`替换成你的endpoint和deployName

== cerebras

**API Key** https://cloud.cerebras.ai/  ->  API Keys

:::

### 中国的大模型平台

::: tabs

== DeepSeek

**API Key** https://platform.deepseek.com/api_keys

== Xiaomi MiMo

**API Key** https://platform.xiaomimimo.com/#/console/api-keys

== 阿里云百炼大模型

**API Key** https://bailian.console.aliyun.com/?apiKey=1#/api-key

**model** https://help.aliyun.com/zh/model-studio/getting-started/models

== 字节跳动火山引擎

**API Key** [创建API Key](https://console.volcengine.com/ark/region:ark+cn-beijing/apiKey?apikey=%7B%7D)获取

**model** https://console.volcengine.com/ark/region:cn-beijing/docs/82379/1330310?lang=zh

== 月之暗面

**API Key** https://platform.moonshot.cn/console/api-keys

== 智谱AI

**API Key** https://bigmodel.cn/usercenter/apikeys

== 讯飞星火大模型

**API Key** 参考[官方文档](https://www.xfyun.cn/doc/spark/HTTP%E8%B0%83%E7%94%A8%E6%96%87%E6%A1%A3.html#_3-%E8%AF%B7%E6%B1%82%E8%AF%B4%E6%98%8E)获取**APIKey**和**APISecret**后，按照**APIKey:APISecret**的格式填入

**model** https://www.xfyun.cn/doc/spark/HTTP%E8%B0%83%E7%94%A8%E6%96%87%E6%A1%A3.html#_3-2-%E8%AF%B7%E6%B1%82%E5%8F%82%E6%95%B0

== 腾讯混元大模型
<!-- 
**SecretId** & **SecretKey** https://console.cloud.tencent.com/cam/capi -->
**API Key** 参考[官方文档](https://cloud.tencent.com/document/product/1729/111008)

**model** https://cloud.tencent.com/document/product/1729/97731

== 百度千帆大模型

**API Key** https://cloud.baidu.com/doc/WENXINWORKSHOP/s/Um2wxbaps

**model** https://cloud.baidu.com/doc/WENXINWORKSHOP/s/Fm2vrveyu

>[!WARNING]
>**API Key**请使用百度智能云IAM的Access Key、Secret Key来生成接口的BearerToken后作为**API Key**填入，或者按照`Access Key`:`Secret Key`的格式直接将两者一起填入**API Key**中。注意，不是千帆ModelBuilder的旧版v1版本接口的API Key、Secret Key，两者不能通用。

== MiniMax

**API Key** https://platform.minimaxi.com/document/Fast%20access?key=66701cf51d57f38758d581b2

:::

### API聚合管理器

也可以使用[new-api](https://github.com/QuantumNous/new-api)等API中继工具，更方便地聚合管理多种大模型平台模型和多个密钥。

使用方法可以参考[此文章](https://www.newapi.ai/zh/docs/apps/luna-translator)

## 特定离线翻译模型

存在一些专为离线翻译所设计，或针对特定场景微调的离线翻译大模型。

大部分模型部署好后，直接使用**大模型通用接口**调用即可。但部分模型，可能需要使用专用的prompt格式，来发挥其更好的翻译效果。

该接口专为这类需要专用prompt格式的模型而来。因此本接口不提供用户自定义的prompt设置，而是使用模型发布者提供的prompt格式。

目前，本接口支持以下模型：

| 作者 | 模型 | 语言 |
| ---- | ---------- | ---------- | 
| tencent | Hy-MT2 | 通用 |
| IndexTeam | Index-Translate | 通用 |
| SakuraLLM | SakuraLLM & GalTransl | 日语 -> 中文 |

<!-- 
部署方法可参考 https://github.com/SakuraLLM/SakuraLLM/wiki ，也可以部署到[Kaggle](https://kaggle.com/kernels/welcome?src=https://lunatranslator.org/nginxfile/llamacpp.ipynb) -->
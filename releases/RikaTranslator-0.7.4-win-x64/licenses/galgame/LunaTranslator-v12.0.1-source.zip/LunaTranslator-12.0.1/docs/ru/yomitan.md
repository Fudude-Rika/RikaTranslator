# Установка расширения браузера Yomitan

1. Убедитесь, что движок отображения — Webview2
  
   Для использования расширения браузера необходим Webview2. Если система не поддерживает Webview2, по умолчанию движок отображения будет Webview2.

   ![img](https://image.lunatranslator.org/en/yomitan.png)

1. Включите **Использовать расширение браузера** и добавьте расширение Yomitan.

    >[!WARNING]
    >Вам следует добавить плагин для версии Chrome/Edge. Плагин для версии Firefox несовместим.



   ![img](https://image.lunatranslator.org/en/yomitan3.png)

   ![img](https://image.lunatranslator.org/zh/yomitan2.png)

1. Дождитесь завершения инициализации, затем настройте Yomitan.

   >[!WARNING]
   >Иногда после добавления плагина он может не распознаваться. Вам нужно закрыть программное обеспечение и снова открыть его, чтобы он распознался.

   ![img](https://image.lunatranslator.org/en/yomitan4.png)

1. Итоговый результат

   > [!TIP]
   > По умолчанию главное окно автоматически изменяет размер в зависимости от текста и содержимого перевода, что также влияет на размер окна Yomitan.
   >
   > Перейдите в **Настройки отображения** → **Настройки интерфейса** → **Главный интерфейс** и снимите флажок **Автоматическая регулировка высоты**.
   >
   > ![img](https://image.lunatranslator.org/en/yomi9.png)

   ![img](https://image.lunatranslator.org/zh/yomitan5.png)

1. Помимо основного интерфейса, расширение браузера можно использовать в окне истории текста, но по умолчанию оно отключено для экономии ресурсов.

   ![img](https://image.lunatranslator.org/zh/yomitan7.png)

   ![img](https://image.lunatranslator.org/zh/yomitan6.png)

   ![img](https://image.lunatranslator.org/zh/yomitan8.png)
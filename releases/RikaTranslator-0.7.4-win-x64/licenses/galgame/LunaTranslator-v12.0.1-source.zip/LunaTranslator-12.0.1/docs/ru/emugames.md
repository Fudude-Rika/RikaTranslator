# Поддержка игр эмуляторов

LunaTranslator поддерживает большое количество игр через эмуляторы. Для игр, которые не поддерживаются, пожалуйста, отправьте мне [issue](https://lunatranslator.org/Resource/game_support).

| Платформа | Поддерживаемые эмуляторы |
<!--@include: ../emusupportlist/all.md-->
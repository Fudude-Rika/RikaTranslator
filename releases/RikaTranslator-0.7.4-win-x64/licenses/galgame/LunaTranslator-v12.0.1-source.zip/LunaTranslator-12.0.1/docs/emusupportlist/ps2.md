|  | ID       | Game                |
| ---- | ---------- | ------------------- |
|  | SLPM-62586 | THE 鑑識官 |
|  | SLPM-65653 | Darling Special Backlash ～恋のエキゾースト・ヒート～ |
|  | SLPM-65886 | ガイザード・レボリューション ～ 僕らは想いを身に纏う ～ |
|  | SLPM-66729 & SLPM-66730 | 少年陰陽師 翼よいま、天へ還れ |
|  | SLPS-25516 | フタコイ オルタナティブ 恋と少女とマシンガン |
|  | SLPS-25796 | 俺の下でAGAKE |
|  | SLPM-65368 | D・N・ANGEL TV Animation Series ～紅の翼～ |
|  | SLPS-25929 | リトルアンカー |
|  | SLPM-66246 | デビルサマナー 葛葉ライドウ対超力兵団 |
|  | SLPM-66679 | デビルサマナー 葛葉ライドウ 対 アバドン王 Plus |
|  | SLPM-66608 | テニスの王子様 ドキドキサバイバル 山麓のMystic |
|  | SLPM-66219 | テニスの王子様 ～学園祭の王子様～ |
|  | SLPS-25621 | かしまし ～ガールミーツガール～「初めての夏物語。」 |
|  | SLPM-66338 | EVE ~new generation~ |
|  | SLPM-65363 | 少女義経伝 |
|  | SLPM-65988 | 少女義経伝・弐 ～刻を超える契り～ |
|  | SLPS-25804 & SLPS-25810 | DEAR My SUN！！ ～ムスコ★育成★狂騒曲～ |
|  | SLPS-25332 | SNOW |
|  | SLPS-25599 | 灼眼のシャナ |
|  | SLPM-55175 | Under the Moon ～クレセント～ |
|  | SLPM-65703 | ダブルリアクション！ プラス |
|  | SLPS-25757 & SLPS-25758 | ななついろ★ドロップス Pure！！ |
|  | SLPM-55259 | デザート・キングダム |
|  | SLPS-25850 | キミキス [eb!コレ+] |
|  | SLPS-25643 | キミキス |
|  | SLPS-25868 | 花宵ロマネスク 愛と哀しみ−それは君のためのアリア |
|  | SLPM-66203 | フラグメンツ・ブルー |
|  | SLPS-25188 | Erde ～ネズの樹の下で～ |
|  | SLPM-66351 | そしてこの宇宙にきらめく君の詩 |
|  | SLPM-66659 | そしてこの宇宙にきらめく君の詩 XXX |
|  | SLPM-65054 | 暴れん坊プリンセス |
|  | SLPM-66453 & SLPM-66454 | 緋色の欠片 ～玉依姫奇譚～ |
|  | SLPM-55216 | 緋色の欠片 愛蔵版 ～玉依姫奇譚～ |
|  | SLPM-66779 & SLPM-66780 | ギャラクシーエンジェルⅡ 無限回廊の鍵 |
|  | SLPM-65393 | 漢のためのバイブル THE 友情アドベンチャー ～炎多留・魂～ |
|  | SLPM-62597 | 学園ヘヴン おかわりっ！ |
|  | SLPS-25693 | プリンセス・プリンセス 姫たちのアブナい放課後 |
|  | SLPM-55103 | モノクローム・ファクター cross road |
|  | SLPM-66737 | 桜蘭高校ホスト部 |
|  | SLPM-65016 & SLPM-65017 | Love Songs アイドルがクラスメ～ト |
|  | SLPM-55206 | S.Y.K ～新説西遊記～ |
|  | SLPM-66855 & SLPM-66856 | 咎狗の血 True Blood |
|  | SLPM-55166 | 風色サーフ |
|  | SLPM-66845 | 悠久ノ桜 |
|  | SLPM-66214 | WHITE CLARITY ～And The tears became you.～ |
|  | SLPS-25282 | 学園ヘヴン BOY'S LOVE SCRAMBLE！ |
|  | SLPM-55121 | 不確定世界の探偵紳士 ～悪行双麻の事件ファイル～ |
|  | SLPS-25228 | 第2次スーパーロボット大戦α |
|  | SLPS-25887 | スーパーロボット大戦Ｚ |
|  | SLPS-25920 | スーパーロボット大戦Z スペシャルディスク |
|  | SLPM-66882 | はかれなはーと ～君がために輝きを～ |
|  | SLPM-66471 | 花帰葬 |
|  | SLPS-25444 | Cherry blossom ～チェリーブロッサム～ |
|  | SLPM-66390 | 薔薇ノ木ニ薔薇ノ花咲ク -Das Versprechen- |
|  | SLPM-55032 | ピヨたん ～お屋敷潜入大作戦～ |
|  | SLPS-25494 | Fragrance Tale ～フレグランス テイル～ |
|  | SLPM-65971 | そして僕らは、・・・and he said |
|  | SLPM-65710 | Apocripha/0 |
|  | SLPM-65512 & SLPM-65513 | Angel's Feather |
|  | SLPM-65943 | Angel's Feather −黒の残影− |
|  | SLPM-66980 | 銀のエクリプス |
|  | SLPM-65910 | カフェ・リンドバーグ -summer season- |
|  | SLPM-55274 | 裏切りは僕の名前を知っている ～黄昏に堕ちた祈り～ |
|  | SLPM-66376 | きみスタ ～きみとスタディ～ |
|  | SLPS-25766 | オレンジハニー 僕はキミに恋してる |
|  | SLPM-55053 | 紫の焔 |
|  | SLPM-62122 | ヘルミーナとクルス |
|  | SLPM-65154 | 君が望む永遠 ～Rumbling hearts～ |
|  | SLPM-65239 | エンジェリック・コンサート |
|  | SLPS-25223 | Canvas～セピア色のモチーフ～ |
|  | SLPS-25256 | Never7 ～the end of infinity～ |
|  | SLPS-25219 | カナリア～この想いを歌に乗せて～ |
|  | SLPM-65450 | 探偵学園Q ～奇翁館の殺意～ |
|  | SLPM-65273 | トライアングルアゲイン2 |
|  | SLPM-65320 | EVE burst error PLUS |
|  | SLPS-25274 | あいかぎ ～ぬくもりとひだまりの中で～ |
|  | SLPS-25192 & SLPS-25193 | My Merry May |
|  | SLPS-25238 | My Merry Maybe |
|  | SLPM-66045 | My Merry May with be |
|  | SLPM-65301 | とらかぷっ！だーっしゅ！！でらっくすぱっく |
|  | SLPM-65295 | カフェ・リトルウィッシュ ～魔法のレシピ～ |
|  | SLPS-25235 | ゆめりあ |
|  | SLPM-65275 | 最終兵器彼女 |
|  | SLPS-25292 | D→A:BLACK |
|  | SLPM-65255 | ビストロ・きゅーぴっと2 特別版 |
|  | SLPS-25396 | ファンタスティックフォーチュン2 ☆☆☆ |
|  | SLPM-65347 | ビストロ・きゅーぴっと2 特別版 |
|  | SLPS-25245 | トゥルーラブストーリー サマーデイズ アンド イエット... |
|  | SLPM-65306 | SAKURA～雪月華～ |
|  | SLPS-25248 | キノの旅 -the Beautiful World- |
|  | SLPM-65281 & SLPM-65282 | グリーングリーン ～鐘の音ロマンティック～ |
|  | SLPM-65448 | カンブリアンQTS ～化石になっても～ |
|  | SLPM-66847 | アラビアンズ・ロスト ～The engagement on desert～ |
|  | SLPS-25283 | INTERLUDE |
|  | SLPS-25298 | てんたま -1st Sunny Side- |
|  | SLPM-65520 | てんたま2wins |
|  | SLPM-65550 | Remember11 ～the age of infinity～ |
|  | SLPS-25294 | 宇宙のステルヴィア |
|  | SLPM-65557 | ステディ×スタディ |
|  | SLPM-65592 | ロスト・アヤ・ソフィア |
|  | SLPM-65676 | ふぁいなる・アプローチ |
|  | SLPM-65671 | W ～ウィッシュ～ |
|  | SLPS-25438 | D→A:WHITE |
|  | SLPM-65585 | Princess Holiday～転がるりんご亭千夜一夜～ |
|  | SLPM-65535 | おしえて！ ぽぽたん |
|  | SLPM-65764 | メンアットワーク！3 愛と青春のハンター学園 |
|  | SLPS-25392 | DESIRE |
|  | SLPS-25807 | セイント・ビースト ～螺旋の章～ |
|  | SLPM-65559 | てのひらをたいように ～永久の絆～ |
|  | SLPM-65639 | パティシエなにゃんこ ～初恋はいちご味～ |
|  | SLPM-65751 | 水月 ～迷心～ |
|  | SLPM-65634 | 夏少女 Promised Summer |
|  | SLPM-65545 | 十六夜れんか ～かみふるさと～ |
|  | SLPM-65524 | オレンジポケット -リュート- |
|  | SLPM-65607 | 3LDK ～幸せになろうよ～ |
|  | SLPS-25433 | 帝国千戦記 |
|  | SLPM-67003 | サクラ大戦 ～熱き血潮に～ |
|  | SLPM-67009 | サクラ大戦Ⅴ ～さらば愛しき人よ～ |
|  | SLPM-65717 | 月は東に日は西に -Operation Sanctuary- |
|  | SLPM-65641 | うたう♪タンブリング・ダイス ～私たち3人、あ・げ・る～ |
|  | SLPM-65546 | CROSS+CHANNEL ～To all people～ |
|  | SLPM-62343 | THE 恋愛ホラーアドベンチャー～漂流少女～ |
|  | SLPM-62509 | THE 外科医 |
|  | SLPM-62375 | THE 娘育成シミュレーション |
|  | SLPM-62207 | THE 恋愛アドベンチャー ～BITTERSWEET FOOLS～ |
|  | SLPS-25581 | THE 呪いのゲーム |
|  | SLPM-65555 | ドラゴンクエストⅤ 天空の花嫁 |
|  | SLPM-66973 | プリンセスナイトメア |
|  | SLPS-25727 | Routes PE |
|  | SLPS-25870 & SLPS-25871 | Drastic Killer |
|  | SLPM-65589 | カラフルBOX ～to LOVE～ |
|  | SLPM-65611 | PIZZICATO POLKA ～縁鎖現夜～ |
|  | SLPM-65785 | なついろ ～星屑のメモリー～ |
|  | SLPS-25348 | こころの扉 初回限定版 [コレクターズエディション] |
|  | SLPS-25395 | センチメンタルプレリュード |
|  | SLPM-65736 | 蒼のままで・・・・・・ |
|  | SLPM-65762 | 片神名 ～喪われた因果律～ |
|  | SLPS-25409 | 双恋—フタコイ— |
|  | SLPM-55149 | ラブルートゼロ KissKiss☆ラビリンス |
|  | SLPM-66998 & SLPM-66999 | ふしぎ遊戯 朱雀異聞 |
|  | SLPM-66023 & SLPM-66024 | ふしぎ遊戯 玄武開伝 外伝 鏡の巫女 |
|  | SLPM-65381 | きまぐれストロベリーカフェ |
|  | SLPM-66543 | Yo-Jin-Bo ～運命のフロイデ～ |
|  | SLPS-25468 | 永遠のアセリア −この大地の果てで− |
|  | SLPM-65832 | IZUMO コンプリート |
|  | SLPM-65334 | 新世紀エヴァンゲリオン 綾波育成計画 with アスカ補完計画 |
|  | SLPM-65867 | 新世紀エヴァンゲリオン 鋼鉄のガールフレンド2nd |
|  | SLPM-65866 | 何処へ行くの、あの日 ～光る明日へ…～ |
|  | SLPM-65895 | 月は切り裂く ～探偵 相楽恭一郎～ |
|  | SLPS-25483 | すい～とし～ずん |
|  | SLPM-65771 | ナチュラル2 -DUO- 桜色の季節 DXパック |
|  | SLPM-65941 | マビノ×スタイル |
|  | SLPM-65918 | Dear My Friend ～Love like powdery snow～ |
|  | SLPM-66026 | 初恋-first kiss- 初回限定版 |
|  | SLPS-25506 | for Symphony ～with all one's heart～ |
|  | SLPM-65962 | ホームメイド ～終の館～ |
|  | SLPM-65964 | まじかる☆ている ～ちっちゃな魔法使い～ |
|  | SLPM-65887 | Like Life an hour |
|  | SLPM-65968 | らぶドル ～Lovely Idol～ |
|  | SLPS-25540 | スクールランブル ねる娘は育つ。 |
|  | SLPM-66052 | 巫女舞 ～永遠の想い～ |
|  | SLPS-25482 | 雪語り リニューアル版 |
|  | SLPM-66083 | ラムネ ～ガラスびんに映る海～ 初回限定版 |
|  | SLPS-25543 | 双恋島 恋と水着のサバイバル！ |
|  | SLPM-66086 | 極上生徒会 |
|  | SLPM-66150 | しろがねの鳥籠 |
|  | SLPM-65937 | 星界の戦旗 |
|  | SLPM-66112 | ふしぎの海のナディア |
|  | SLPM-66157 | ルーンプリンセス 初回限定版 |
|  | SLPM-66069 | 式神の城 七夜月幻想曲 |
|  | SLPM-66254 | ふぁいなりすと |
|  | SLPM-65552 | メタルウルフREV |
|  | SLPM-66245 | ジュエルスオーシャン Star of Sierra Leone |
|  | SLPM-66296 | 闇夜にささやく ～探偵 相楽恭一郎～ |
|  | SLPM-66329 | 魔法先生ネギま！ 課外授業 乙女のドキドキ・ビーチサイド |
|  | SLPS-25617 | e'tude prologue ～揺れ動く心のかたち～ |
|  | SLPM-66331 | 高円寺女子サッカー 1st stage限定版 |
|  | SLPM-66408 | つよきす ～Mighty Heart～ |
|  | SLPM-66357 | ローゼンメイデン ドゥエルヴァルツァ |
|  | SLPM-65296 & SLPM-65297 | F～ファナティック～ |
|  | SLPS-25257 | 想いのかけら ～Close to ～ |
|  | SLPS-25508 | 舞-HiME 運命の系統樹 |
|  | SLPM-66406 | 桜華 ～心輝かせる桜～ |
|  | SLPM-66243 | ギャラクシーエンジェルⅡ ～絶対領域の扉～ |
|  | SLPM-66433 | 魂響 ～御霊送りの詩～ |
|  | SLPM-66457 | あそびにいくヨ！ ～ちきゅうぴんちのこんやくせんげん～ |
|  | SLPS-25669 | スクールランブル二学期 恐怖の(?)夏合宿！ 洋館に幽霊現る！？ お宝を巡って真っ向勝負!!!の巻 |
|  | SLPM-66491 | あやかしびと -幻妖異聞録- |
|  | SLPS-25612 | Strawberry Panic！ |
|  | SLPM-66398 | パルフェ Chocolat Second Style |
|  | SLPM-66239 | レッスルエンジェルス SURVIVOR |
|  | SLPM-66460 | _summer## |
|  | SLPS-25668 | 鳥篭の向こうがわ |
|  | SLPM-66534 | 龍刻 Ryu-Koku |
|  | SLPM-66618 | 夢見師 |
|  | SLPM-66507 | 乙女の事情 |
|  | SLPM-66499 | 神様家族 応援願望 |
|  | SLPM-66530 | Gift -prism- |
|  | SLPM-66495 | 女子高生 GAME'S-HIGH！ |
|  | SLPM-66544 | 世界ノ全テ ～two of us～ |
|  | SLPM-66607 | ホワイトブレス～絆～ |
|  | SLPM-66440 | 保健室へようこそ |
|  | SLPM-66570 | I”s Pure |
|  | SLPM-66565 | REC☆ドキドキ声優パラダイス☆ |
|  | SLPM-66641 | すくぅ～る らぶっ！～恋と希望のメトロノーム～ |
|  | SLPM-66470 | 「ラブ★コン ～パンチDEコント～」[通常版] |
|  | SLPS-25749 | 蒼い空のネオスフィア ～ナノカ・フランカ発明工房記2～ |
|  | SLPM-66611 | 智代アフター ～It's a Wonderful Life～ CS Edition |
|  | SLPS-25719 | はぴねす！でらっくす |
|  | SLPM-66620 | ひぐらしのなく頃に祭 |
|  | SLPM-66734 | きると ～貴方と紡ぐ夢と恋のドレス～ |
|  | SLPS-25689 | シムーン 異薔薇戦争 封印のリ・マージョン |
|  | SLPM-66726 | お嬢様組曲 -Sweet Concert- |
|  | SLPS-25775 | まじしゃんず・あかでみい |
|  | SLPM-66732 | 許嫁 |
|  | SLPM-66755 | 魔女っ娘ア・ラ・モードⅡ ～魔法と剣のストラグル～ |
|  | SLPM-66757 | Que ～エンシェントリーフの妖精～ |
|  | SLPM-66764 | IZUMO零 ～横濱あやかし絵巻～ |
|  | SLPM-66598 | 夜刀姫斬鬼行 -剣の巻- |
|  | SLPM-66605 | キャッスルファンタジア アリハト戦記 |
|  | SLPM-66754 | 月面兎兵器ミーナ -ふたつのPROJECT M- |
|  | SLPM-66285 | プリンセスコンチェルト |
|  | SLPM-66826 | 妖鬼姫伝 ～あやかし幻灯話～ |
|  | SLPM-66879 | StarTRain -your past makes your future- |
|  | SLPM-66805 | カラフルアクアリウム～My Little Mermaid～ |
|  | SLPM-66861 | 熱帯低気圧少女 |
|  | SLPM-66890 | ぷりサガ～プリンセスをさがせ～ |
|  | SLPM-66809 | 最終試験くじら−Alive− |
|  | SLPM-66787 | 水夏A.S+ Eternal Name |
|  | SLPM-66918 | プリンセスメーカー5 |
|  | SLPM-67015 | School Days L×H |
|  | SLPM-66908 | IZUMO2 学園狂想曲 ダブルタクト |
|  | SLPM-66933 | 君が主で執事が俺で～お仕え日記～ |
|  | SLPM-66942 | Φなる・あぷろーち 2 ～1st priority～ |
|  | SLPM-66901 | 12RIVEN - the Ψcliminal of integral - |
|  | SLPM-66919 | 吸血奇譚 ムーンタイズ |
|  | SLPM-66935 | true tears～トゥルーティアーズ～ |
|  | SLPM-66846 | プリズム・アーク -AWAKE- |
|  | SLPM-66997 | 終末少女幻想アリスマチック Apocalypse |
|  | SLPM-66969 | ほしがりエンプーサ |
|  | SLPM-66920 | ほしフル～星の降る街～ |
|  | SLPM-66921 | H2Oプラス |
|  | SLPM-55009 | Lの季節2 ～Invisible Memories～ |
|  | SLPM-66958 | アオイシロ |
|  | SLPM-55016 | よつのは ～a journey of sincerity～ |
|  | SLPM-55026 | 白銀のソレイユ Contract to the future 未来への契約 |
|  | SLPM-55047 | Sugar+Spice！ ～あの子のステキな何もかも～ |
|  | SLPM-55028 | シークレットゲーム -KILLER QUEEN- |
|  | SLPM-55058 | レッスルエンジェルス サバイバー2 |
|  | SLPM-55071 | 夢見白書 ～Second Dream～ |
|  | SLPM-55079 | Scarlett ～日常の境界線～ |
|  | SLPM-55098 | 恋する乙女と守護の楯 |
|  | SLPM-66441 | 大奥記 |
|  | SLPM-55102 | Piaキャロットへようこそ！！G.P. ～学園プリンセス～ |
|  | SLPS-25221 | Piaキャロットへようこそ！！3 ～round summer～ |
|  | SLPM-55136 | Clear ～新しい風の吹く丘で～ |
|  | SLPM-55159 | ヒャッコ よろずや事件簿！ |
|  | SLPM-55052 | トリガーハート エグゼリカ エンハンスド |
|  | SLPS-25226 | Memories Off Duet ～1st & 2nd Stories～ |
|  | SLPM-65610 | Memories Off ～それから～ |
|  | SLPM-66352 | Memories Off ～それから again～ |
|  | SLPM-65857 | Memories Off AfterRain vol.1 折鶴 |
|  | SLPM-65903 | Memories Off AfterRain Vol.2 想演 |
|  | SLPM-66146 & SLPM-66147 | Memories Off #5 とぎれたフィルム |
|  | SLPM-66791 | Memories Off #5 encore |
|  | SLPM-66988 | Memories Off 6 ～T-Wave～ |
|  | SLPM-55197 | Memories Off 6 Next Relation |
|  | SLPS-25278 | メモオフみっくす |
|  | SLPM-55184 | メルティブラッド アクトレスアゲイン |
|  | SLPM-55154 | つよきす2学期 ～Swift Love～ |
|  | SLPM-55185 | Sweet Honey Coming [DXパック] |
|  | SLPM-55220 | お掃除戦隊くりーんきーぱー H |
|  | SLPM-62784 | 顔のない月 Select story |
|  | SLPM-55240 | ef - A Fairy Tale of the Two. |
|  | SLPM-55243 | スズノネセブン！～Rebirth Knot～ |
|  | SLPS-25896 | 萌え萌え2次大戦（略）☆デラックス |
|  | SLPS-25956 | 萌え萌え2次大戦(略)2[chu～♪] |
|  | SLPM-55174 | ストライクウィッチーズ あなたとできること |
|  | SLPM-55068 | 恋姫†夢想 ～ドキッ☆乙女だらけの三国志演義～ |
|  | SLPM-55288 | 真・恋姫†夢想 ～乙女繚乱☆三国志演義～ |
|  | SLPM-66743 | 神曲奏界ポリフォニカ |
|  | SLPM-66977 | 神曲奏界ポリフォニカ 0～4話フルパック |
|  | SLPM-55095 | 神曲奏界ポリフォニカ THE BLACK -EPSODE 1 & 2 BOX EDITION- |
|  | SLPM-66909 | 神曲奏界ポリフォニカ ３&４話完結編 |
|  | SLPM-55270 | 神曲奏界ポリフォニカ アフタースクール |
|  | SLPM-55225 | 戦極姫 ～戦乱に舞う乙女達～ |
|  | SLPM-55278 | 戦極姫2・炎 ～百華、戦乱辰風の如く～ |
|  | SLPM-55263 | 花と乙女に祝福を ～春風の贈り物～ |
|  | SLPM-65682 | Monochrome (モノクローム) |
|  | SLPS-25039 & SLPS-25051 | Missing Blue |
|  | SLPS-25759 | 四八 （仮） |
|  | SLPS-25135 | かまいたちの夜2 ～監獄島のわらべ唄～ |
|  | SLPM-66452 | かまいたちの夜x3 三日月島事件の真相 |
|  | SLPM-55200 | 桃華月憚 ～光風の陵王～ |
|  | SLPM-65136 & SLPM-65125 & SLPS-25026 | 夏色の砂時計 |
|  | SLPM-65786 | なついろ ～星屑のメモリー～ |
|  | SLPM-65355 & SLPM-65356 | 夏色小町【一日千夏】 |
|  | SLPS-25941 | SDガンダム - G GENERATION WARS |
|  | SLPM-66458 | 風雨来記 |
|  | SLPM-66163 | 風雨来記2 |
|  | SLPM-55006 | あかね色に染まる坂 ぱられる |
|  | SLPS-20196 | 赤川次郎ミステリー月の光　 ～沈める鐘の殺人～ |
|  | SLPS-25081 | 最終電車 |
|  | SLPS-25276 | 夏夢夜話 |
|  | SLPM-65684 | マイネリーベ 優美なる記憶 |
|  | SLPM-66247 | マイネリーベⅡ ～誇りと正義と愛～ |
|  | SLPM-66286 & SLPM-66170 & SLPM-74238 | 幻想水滸伝V |
|  | SLPM-66298 | セパレイトハーツ (Separate Hearts) |
|  | SLPM-65732 | アカイイト |
|  | SLPM-65914 | Nana |
|  | SLPM-66302 | CLANNAD - ゲオオンラインストア |
|  | SLPS-25547 | 苺ましまろ |
|  | SLPS-25677 | ブラッドプラス ワン ナイト キス |
|  | SLPM-55195 | プリンセスラバー！ Eternal Love For My Lady |
|  | SLPM-65997 | 破滅のマルス |
|  | SLPS-25385 | フレンズ ～青春の輝き～ |
|  | SLPM-66399 | SAMURAI 7 |
|  | SLPM-66332 | 高円寺女子サッカー |
|  | SLPS-25809 | 銀魂 銀さんと一緒！ボクのかぶき町日記 |
|  | SLPS-20352 | 好きなものは好きだからしょうがない！！ -FIRST LIMIT & TARGET†NIGHTS- Sukisho！ Episode ＃01+＃02 |
|  | SLPS-20394 | 好きなものは好きだからしょうがない！！ -RAIN- Sukisyo！ Episode #03 |
|  | SLPS-25871 | ドラスティックキラー |
|  | SLPS-25678 & SLPS-25679 | うたわれるもの 散りゆく者への子守唄 |
|  | SLPS-25150 | Only you リベルクルス ドラマCD付き |
|  | SLPM-65400 | D.C.P.S. ～ダ・カーポ～ プラスシチュエーション |
|  | SLPM-66922 | D.C.Ⅱ P.S. ～ダ・カーポⅡ～ プラスシチュエーション DXパック |
|  | SLPM-66905 | D.C. ～ダ・カーポ～ the Origin |
|  | SLPM-55156 | D.C.I.F. ～ダ・カーポ～イノセント・フィナーレ～ |
|  | SLPM-66225 | D.C.F.S. ～ダ・カーポ～ フォーシーズンズ DXパック |
|  | SLPM-66437 | Soul Link EXTENSION |
|  | SLPM-65396 | デ・ジ・キャラット ファンタジー エクセレント |
|  | SLPM-66272 | I/O |
|  | SLPM-66569 | シークレット・オブ・エヴァンゲリオン |
|  | SLPM-55269 | PANDORA ～君の名前を僕は知る～ |
|  | SLPM-66293 | 学園アリス ～きらきら★メモリーキッス～ |
|  | SLPM-65481 | After...～忘れえぬ絆～ |
|  | SLPM-66858 | いつか、届く、あの空に。 ～陽の道と緋の昏と～ |
|  | SLPS-25830 | ゼロの使い魔 夢魔が紡ぐ夜風の幻想曲 |
|  | SLPS-25897 | ゼロの使い魔 迷子の終止符と幾千の交響曲 |
|  | SLPS-25709 | ゼロの使い魔 小悪魔と春風の協奏曲 |
|  | SLPM-55170 | スキップ・ビート |
|  | SLPM-66891 & SLPM-66892 | Myself;Yourself |
|  | SLPM-55163 | Myself; Yourself それぞれのfinale |
|  | SLPM-55014 | ARIA The ORIGINATION ～蒼い惑星のエルシエロ～ |
|  | SLPM-66536 | ARIA The NATURAL ～遠い記憶のミラージュ～ |
|  | SLPM-55264 | 猛獣使いと王子様 |
|  | SLPM-65843 | 120円の春 |
|  | SLPM-66186 | ゲームになったよ！ドクロちゃん～健康診断大作戦～ |
|  | SLPM-55213 | 地獄少女 澪縁 |
|  | SLPM-66975 | エーデルブルーメ |
|  | SLPM-55227 | セキレイ ～未来からのおくりもの～ |
|  | SLPM-66513 | Fate/stay night[Realta Nua] |
|  | SLPS-25604 | アルトネリコ 世界の終わりで詩い続ける少女 |
|  | SLPS-73249 | アルトネリコ 世界の終わりで詩い続ける少女 [PlayStation2 the Best] |
|  | SLPS-25819 | アルトネリコ2 世界に響く少女たちの創造詩 |
|  | SLPS-73263 | アルトネリコ2 世界に響く少女たちの創造詩 [PlayStation2 the Best] |
|  | SLPM-55281 | CLOCK ZERO ～終焉の一秒～ |
|  | SLPS-25414 | ToHeart2 |
|  | SLPM-66582 | 仔羊捕獲ケーカク！ スイートボーイズライフ |
|  | SLPM-66817 | Palais de Reine |
|  | SLPS-25378 & SLPS-25379 | 東京魔人學園外法帖血風録 |
|  | SLPS-25220 | エリュシオン～永遠のサンクチュアリ～ |
|  | SLPS-25902 | 純情ロマンチカ ～恋のドキドキ大作戦 |
|  | SLPS-25662 | 今日からマ王！はじマりの旅 [プレミアムBOX] |
|  | SLPS-25801 | 今日からマ王！ 眞マ国の休日 |
|  | SLPM-65957 | 遙かなる時空の中で ～八葉抄～ |
|  | SLPM-55138 | 遙かなる時空の中で 夢の浮橋 |
|  | SLPM-66548 | 遙かなる時空の中で 舞一夜 |
|  | SLPM-65834 & SLPM-65849 & SLPM-65850 | 遙かなる時空の中で3 |
|  | SLPM-66344 & SLPM-66347 & SLPM-66348 | 遙かなる時空の中で3 運命の迷宮 |
|  | SLPM-66099 & SLPM-66100 & SLPM-66127 | 遙かなる時空の中で3 十六夜記 Harukanaru Toki no Naka de 3 - Izayoiki |
|  | SLPM-66952 | 遙かなる時空の中で4 |
|  | SLPM-65848 | 空色の風琴 ～Remix～ |
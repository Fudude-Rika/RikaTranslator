# Giao diện dịch mô hình lớn

## Giao Diện Chung Cho Mô Hình Lớn

::: details Sử Dụng Nhiều Giao Diện Mô Hình Lớn Đồng Thời?
Nếu bạn chỉ có nhiều khóa khác nhau và muốn luân phiên sử dụng chúng, chỉ cần tách chúng bằng `|`.

Tuy nhiên, đôi khi bạn có thể muốn sử dụng nhiều địa chỉ giao diện API, lời nhắc, mô hình hoặc tham số khác nhau đồng thời để so sánh kết quả dịch thuật. Đây là cách thực hiện:

1. Nhấp vào nút "+" phía trên và chọn giao diện mô hình lớn thông dụng
   ![img](https://image.lunatranslator.org/zh/damoxing/plus.png)
1. Một cửa sổ sẽ bật lên - hãy đặt tên cho nó. Thao tác này sẽ sao chép cài đặt và API hiện tại của giao diện mô hình lớn thông dụng
   ![img](https://image.lunatranslator.org/zh/damoxing/name.png)
1. Kích hoạt giao diện đã sao chép và cấu hình nó riêng biệt. Giao diện đã sao chép có thể chạy song song với giao diện gốc, cho phép bạn sử dụng nhiều cài đặt khác nhau đồng thời.
   ![img](https://image.lunatranslator.org/zh/damoxing/extraapi3.png)
:::

### Giải thích tham số

1. #### Địa chỉ API

    `Địa chỉ API` của hầu hết các nền tảng mô hình lớn phổ biến có thể được chọn trong danh sách thả xuống, nhưng có thể bị thiếu một số. Đối với các API không được liệt kê, vui lòng tự tham khảo tài liệu của nền tảng để điền.

1. #### API Key

    `API Key` có thể lấy được trên nền tảng. Đối với nhiều Key được thêm vào, hệ thống sẽ tự động luân phiên và điều chỉnh trọng số của Key dựa trên phản hồi lỗi.

1. #### Model

    Với hầu hết các nền tảng, sau khi điền `Địa chỉ API` và `API Key`, nhấp vào nút làm mới bên cạnh `model` để lấy danh sách model khả dụng.

    Nếu nền tảng không hỗ trợ API lấy model và model bạn cần không có trong danh sách mặc định, vui lòng tham khảo tài liệu chính thức của API để điền model thủ công.

1. #### Xuất luồng (Streaming output)

    Khi bật, nội dung đầu ra của model sẽ được hiển thị theo luồng tăng dần. Nếu tắt, tất cả nội dung sẽ được hiển thị một lần sau khi model hoàn thành.

1. #### Số lượng ngữ cảnh đính kèm

    Sẽ đính kèm một số lịch sử văn bản gốc và API dịch cho mô hình lớn để tối ưu hóa bản dịch. Đặt thành 0 sẽ tắt tối ưu hóa này.


1. #### Tùy chỉnh system prompt / Tùy chỉnh user message / Prefill {#anchor-prompt}

    Một số cách khác nhau để kiểm soát nội dung đầu ra, có thể thiết lập theo sở thích hoặc sử dụng mặc định.

    Trong prompt hệ thống tùy chỉnh và tin nhắn người dùng, bạn có thể sử dụng các trường để tham chiếu thông tin:
    - `{sentence}`: Văn bản cần dịch
    - `{srclang}` và `{tgtlang}`: Ngôn ngữ nguồn và ngôn ngữ đích. Nếu chỉ sử dụng tiếng Anh trong prompt, chúng sẽ được thay thế bằng bản dịch tiếng Anh của tên ngôn ngữ. Ngược lại, chúng sẽ được thay thế bằng bản dịch tên ngôn ngữ trong ngôn ngữ UI hiện tại.
    - `{contextOriginal[N]}` và `{contextTranslation[N]}` và `{contextBoth[N]}`: N câu lịch sử văn bản gốc, bản dịch và cả hai. Nếu đầu vào là `contextBoth[N]`, giá trị của `附带上下文个数` sẽ được tham chiếu; nếu đầu vào là `contextBoth[10]`, số lượng 10 đã nhập sẽ được sử dụng.
    - `{DictWithPrompt[XXXXX]}`: Trường này có thể tham chiếu các mục trong "Danh sách Dịch Thuật Ngữ Riêng". **Nếu không tìm thấy mục phù hợp, trường này sẽ bị xóa để tránh làm hỏng nội dung dịch**. Ở đây, `XXXXX` là một đoạn hướng dẫn LLM sử dụng các mục đã cho để tối ưu hóa bản dịch. Nó có thể được tùy chỉnh hoặc vô hiệu hóa tin nhắn tùy chỉnh của người dùng để sử dụng lời nhắc mặc định.

1. #### Temperature / max tokens / top p / frequency penalty

    Đối với một số nền tảng và mô hình, các tham số như `top p` và `frequency penalty` có thể không được chấp nhận bởi giao diện, hoặc tham số `max tokens` đã bị loại bỏ và thay bằng `max completion tokens`. Việc kích hoạt hoặc hủy kích hoạt công tắc có thể giải quyết những vấn đề này.

1. #### reasoning effort
    Kiểm soát cường độ suy luận được hỗ trợ bởi một số nền tảng.

    Đối với nền tảng Gemini, các tùy chọn sẽ tự động được ánh xạ tới `thinkingBudget` của Gemini. Quy tắc ánh xạ như sau:
    
    none/minimal -> 0 (tắt suy luận, không áp dụng cho mô hình Gemini-2.5-Pro), low -> 512, medium -> -1 (bật suy luận động), high/xhigh -> 24576.

1. #### thinking.type
    Công tắc chế độ suy nghĩ được hỗ trợ bởi một số nền tảng (chủ yếu là DeepSeek).

1. #### Các tham số khác

    Trên đây chỉ cung cấp một số tham số phổ biến. Nếu nền tảng bạn sử dụng cung cấp các tham số hữu ích khác chưa được liệt kê, có thể tự thêm cặp khóa-giá trị.

## Các nền tảng mô hình lớn phổ biến

### Nền tảng mô hình lớn ở Âu Mỹ  

::: tabs

== OpenAI

**API Key** https://platform.openai.com/api-keys

== Gemini

**API Key** https://aistudio.google.com/app/apikey

== Nvidia

**API Key** https://build.nvidia.com/explore/discover

== Claude

**API Key** https://console.anthropic.com/

**model** https://docs.anthropic.com/en/docs/about-claude/models

== Cohere

**API Key** https://dashboard.cohere.com/api-keys

== x.ai

**API Key** https://console.x.ai/

== Groq

**API Key** https://console.groq.com/keys

== OpenRouter

**API Key** https://openrouter.ai/settings/keys

== Mistral AI

**API Key** https://console.mistral.ai/api-keys/

== Azure

**Địa Chỉ Giao Diện API** `https://{endpoint}.openai.azure.com/openai/deployments/{deployName}/chat/completions?api-version=2023-12-01-preview`

Thay thế `{endpoint}` và `{deployName}` bằng endpoint và deployName của bạn.

== Cerebras

**API Key** https://cloud.cerebras.ai/  ->  API Keys

:::

### Nền tảng mô hình lớn ở Trung Quốc  

::: tabs

== DeepSeek

**API Key** https://platform.deepseek.com/api_keys

== Xiaomi MiMo

**API Key** https://platform.xiaomimimo.com/#/console/api-keys

== Alibaba Cloud Bailian Large Model

**API Key** https://bailian.console.aliyun.com/?apiKey=1#/api-key

**model** https://help.aliyun.com/zh/model-studio/getting-started/models

== Động cơ Volcano của ByteDance

**API Key** [Tạo API Key](https://console.volcengine.com/ark/region:ark+cn-beijing/apiKey?apikey=%7B%7D) để lấy.

**model** https://console.volcengine.com/ark/region:cn-beijing/docs/82379/1330310?lang=zh

== Moonshot AI

**API Key** https://platform.moonshot.cn/console/api-keys

== Zhipu AI

**API Key** https://bigmodel.cn/usercenter/apikeys

**model** https://bigmodel.cn/dev/howuse/model

== iFlytek Spark Large Model

**API Key** Tham khảo [tài liệu chính thức](https://www.xfyun.cn/doc/spark/HTTP%E8%B0%83%E7%94%A8%E6%96%87%E6%A1%A3.html#_3-%E8%AF%B7%E6%B1%82%E8%AF%B4%E6%98%8E) để lấy **APIKey** và **APISecret**, sau đó điền theo định dạng `APIKey:APISecret`.

**model** https://www.xfyun.cn/doc/spark/HTTP%E8%B0%83%E7%94%A8%E6%96%87%E6%A1%A3.html#_3-2-%E8%AF%B7%E6%B1%82%E5%8F%82%E6%95%B0

== Tencent Hunyuan Large Model

**API Key** Tham khảo [tài liệu chính thức](https://cloud.tencent.com/document/product/1729/111008)

**model** https://cloud.tencent.com/document/product/1729/97731

== Baidu Qianfan Large Model

**API Key** https://cloud.baidu.com/doc/WENXINWORKSHOP/s/Um2wxbaps

**model** https://cloud.baidu.com/doc/WENXINWORKSHOP/s/Fm2vrveyu

>[!WARNING]
>**API Key** nên được tạo bằng cách sử dụng Access Key và Secret Key của Baidu Intelligent Cloud IAM để tạo BearerToken cho giao diện, hoặc điền trực tiếp theo định dạng `Access Key`:`Secret Key` trong trường **API Key**. Lưu ý rằng đây không phải là API Key và Secret Key của phiên bản cũ v1 của Qianfan ModelBuilder; chúng không thể thay thế cho nhau.

== MiniMax

**API Key** https://platform.minimaxi.com/document/Fast%20access?key=66701cf51d57f38758d581b2

:::

### Trình quản lý tổng hợp API

Bạn cũng có thể sử dụng các công cụ chuyển tiếp API như [new-api](https://github.com/QuantumNous/new-api) để quản lý tổng hợp nhiều nền tảng mô hình lớn và nhiều khóa một cách thuận tiện hơn.

Để biết phương pháp sử dụng, bạn có thể tham khảo [bài viết này](https://www.newapi.ai/en/docs/apps/luna-translator).


## Các mô hình dịch thuật ngoại tuyến cụ thể

Có một số mô hình lớn được thiết kế đặc biệt cho dịch thuật ngoại tuyến hoặc được tinh chỉnh cho các tình huống cụ thể.

Hầu hết các mô hình, sau khi triển khai, có thể được gọi trực tiếp bằng **giao diện tổng quát cho mô hình lớn**. Tuy nhiên, một số mô hình có thể yêu cầu sử dụng định dạng prompt chuyên dụng để phát huy hiệu quả dịch thuật tốt hơn.

Giao diện này được thiết kế dành riêng cho các mô hình yêu cầu định dạng prompt chuyên dụng như vậy. Do đó, giao diện này không cung cấp cài đặt prompt tùy chỉnh theo người dùng, mà sử dụng định dạng prompt do nhà phát hành mô hình cung cấp.

Hiện tại, giao diện này hỗ trợ các mô hình sau:

| Tác giả | Mô hình | Ngôn ngữ |
| ---- | ---------- | ---------- | 
| tencent | Hy-MT2 | Đa năng |
| IndexTeam | Index-Translate | Đa năng |
| SakuraLLM | SakuraLLM & GalTransl | Tiếng Nhật -> Tiếng Trung |

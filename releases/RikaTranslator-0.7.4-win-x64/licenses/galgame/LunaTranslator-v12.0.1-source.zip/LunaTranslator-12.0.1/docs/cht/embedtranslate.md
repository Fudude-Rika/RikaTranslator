# 內嵌翻譯

## 使用方法

::: danger
首先，不是所有遊戲都支援內嵌。其次，內嵌有一定可能會導致遊戲崩潰。
:::

::: details 如果選擇文字中沒有內嵌這一欄，就代表不支援內嵌。
![img](https://image.lunatranslator.org/zh/embed/noembed.png)
![img](https://image.lunatranslator.org/zh/embed/someembed.png)
:::

對於支援內嵌的遊戲，選擇支援內嵌的文字條目，啟用內嵌即可。

![img](https://image.lunatranslator.org/zh/embed/select.png)

對於支援內嵌的條目，**顯示**和**內嵌**可以隨意選擇是否同時啟用。當同時啟用時，既會在遊戲中嵌入翻譯，也會在軟體視窗中顯示更多翻譯；若只啟用內嵌，則只會在遊戲中顯示嵌入的翻譯，軟體視窗則不會顯示任何內容。

當開始內嵌翻譯後，經常會出現亂碼的情況。遊戲亂碼一般會是**字元集**和**字型**兩種問題。對於英文遊戲，通常是因為遊戲缺少中文**字型**導致的，例如：

![img](https://image.lunatranslator.org/zh/embed/luanma.png)

這時，您需要啟用**修改遊戲字型**，並選擇一個適當的字型，以顯示中文字元

![img](https://image.lunatranslator.org/zh/embed/ziti.png)

修改完畢字型後，中文可以正確的顯示了：

![img](https://image.lunatranslator.org/zh/embed/okembed.png)

對於許多古早日本 Galgame，他們使用自己內建的 Shift_JIS 字元集處理，無法正確處理中文字元，可以嘗試**將漢字轉換成繁體／日式漢字**，減少亂碼的出現。

對於一些較新的遊戲引擎和大部份英文遊戲，一般使用 UTF-8 或 UTF-16 等 Unicode 字元集（如 **KiriKiri**，**Renpy**，**TyranoScript**，**RPG Maker MV** 等），即使出現亂碼一般也是字型的問題，而不是字元集的問題。

![img](https://image.lunatranslator.org/zh/embed/fanti.png)

取消這一設定後，可以正常顯示簡體中文了。但對於一些無法正常顯示簡體中文的遊戲，可以嘗試啟用這一選項來看看能不能正常顯示。

![img](https://image.lunatranslator.org/zh/embed/good.png)

## 內嵌翻譯設定

1. #### 顯示模式

    ![img](https://image.lunatranslator.org/zh/embed/keeporigin.png)

    由於遊戲能顯示的文字行數的限制，所以預設沒有在翻譯和原文中間新增換行。如果確定可以容納，可以透過在**翻譯優化**->**翻譯結果修正**中新增一項正則表達式來在翻譯前面新增一個換行來實現。

    ![img](https://image.lunatranslator.org/zh/embed/addspace.png)

1. #### 翻譯等待時間

    內嵌翻譯的原理是在遊戲顯示文字前，在某個函式中停住遊戲，把其中要顯示的文字發送給翻譯器，等待到翻譯後把記憶體中的文字修改成翻譯的文字，然後讓遊戲繼續執行來顯示翻譯。因此**當使用的翻譯速度較慢時，是一定會導致遊戲卡頓的**。可以透過限制等待的時間，來避免翻譯過慢導致長時間卡頓。

1. #### 將漢字轉換成繁體／日式漢字

    將漢字轉換成繁體字與日本漢字。

1. #### 限制每行字數

    有時某些遊戲每行能顯示的字元數量是有限的，超出長度的內容會顯示到文字框右邊的更外面而無法顯示。可以透過這一設定來手動分行以避免該情況。

    ![img](https://image.lunatranslator.org/zh/embed/limitlength.png)

1. #### 修改遊戲字型

    修改遊戲中文字的顯示字型。

1. #### 修改遊戲字體相對大小

    略


1. #### 清除遊戲內顯示的文字

    啟用該選項後，遊戲內要顯示內嵌文字處的內容將被清空。

    該選項可能滿足以下需要：

    1. 有時，內嵌翻譯有無法解決的字元編碼和字型無法顯示的問題。啟用該選項，然後將軟體視窗覆蓋到原本遊戲中顯示文字的地方，可以偽裝成內嵌翻譯的樣子。

    1. 有時，我們並不是想要進行內嵌翻譯，而是使用外掛翻譯時，有可能覺得將視窗放在文字區會和原文字重疊，放在其他地方會遮擋畫面。

    1. 有時，我們僅想要用來學習日文，然後遊戲文字沒有對文字加讀音或雙語對照的功能。

# 中文分詞及注音

1. ## 下載依賴庫並解壓
    
    下載 [中文分詞器和拼音轉換器](https://lunatranslator.org/Resource/otherresource/jiebapinyin)，將內容解壓縮到軟體的**根目錄**、**LunaTranslator 目錄**或**設定檔目錄 (userconfig)** 中。


1. ## 切換語言

    切換源語言為**簡體中文**或**繁體中文**

1. ## 最終效果

    ![img](https://image.lunatranslator.org/zh/jiebapinyin.png)

1. ## 新增中文->英文詞典查詞

     下載[shawkynasr/CC-CEDICT](https://github.com/shawkynasr/CC-CEDICT)，新增到**辭書**->**離線**->**MDict**即可。

# ネットワークサービス

## Webページ

1. #### /

    ナビゲーションページ

1. #### /page/mainui

    メインウィンドウに表示されるテキスト内容と同期します。

1. #### /page/transhist

    翻訳履歴に表示されるテキスト内容と同期します。

1. #### /page/dictionary

    単語検索ページ。/page/mainuiで単語をクリックして検索すると、このページが表示されます。

1. #### /page/manyinone

    上記3つのページを統合したページです。このウィンドウの/page/mainuiサブセクションで単語をクリックして検索すると、新しい検索ウィンドウが開かず、現在のウィンドウの/page/dictionaryサブセクションで検索結果が表示されます。

1. #### /page/translate

    翻訳インタフェース

1. #### /page/ocr

    OCRインタフェース

1. #### /page/tts

    TTSインタフェース

## APIサービス

### HTTPサービス

1. #### /api/translate

    クエリパラメータ`text`の指定が必須です。

    パラメータ`id`（翻訳器のID）が指定された場合、その翻訳器を使用して翻訳を行います。指定されていない場合は、最速の翻訳APIが返されます。

    `application/json`形式で返され、翻訳器のID`id`、名前`name`、翻訳結果`result`が含まれます。

1. #### /api/dictionary

    クエリパラメータ`word`の指定は必須です。

    パラメータ`id`（辞書のID）を指定した場合、その辞書の検索結果が`application/json`オブジェクトとして返されます。返されるオブジェクトには辞書ID`id`、辞書名`name`、HTMLコンテンツ`result`が含まれます。検索に失敗した場合は空のオブジェクトが返されます。

    `id`を指定しない場合、すべての辞書が検索され、`event/text-stream`が返されます。各イベントは辞書ID`id`、辞書名`name`、HTMLコンテンツ`result`を含むJSONオブジェクトです。

1. #### /api/mecab

   クエリパラメータ`text`の指定が必須です。

   `text`に対するMeCabの解析結果を返します。
   
1. #### /api/tts

   クエリパラメータ`text`の指定が必須です。

   音声データ（バイナリ形式）を返します。

1. #### /api/ocr

   POSTメソッドを使用し、base64エンコードされた画像データを含む`image`フィールドのJSONリクエストを送信してください。
   
1. #### /api/list/dictionary  
    現在利用可能な辞書を一覧表示します  

1. #### /api/list/translator  
    現在利用可能な翻訳ツールを一覧表示します  

1. #### /api/textinput

    パラメータ `text` の指定が必須です  

### WebSocketサービス

1.  #### /api/ws/text/origin

    抽出されたすべての原文テキストを継続的に出力します。

1.  #### /api/ws/text/trans

    すべての翻訳結果を継続的に出力します。
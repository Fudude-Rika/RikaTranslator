# Yomitanブラウザ拡張機能のインストール

1. 表示エンジンがWebview2であることを確認
  
   ブラウザ拡張機能を使用するにはWebview2が必要です。システムがWebview2をサポートしていない場合を除き、デフォルトの表示エンジンはWebview2です。

   ![img](https://image.lunatranslator.org/en/yomitan.png)

1. **ブラウザ拡張機能を使用**を有効にし、yomitan拡張機能を追加します。

    >[!WARNING]
    >Chrome / Edgeバージョンのプラグインを追加してください。Firefoxバージョンのプラグインは互換性がありません。


   ![img](https://image.lunatranslator.org/en/yomitan3.png)

   ![img](https://image.lunatranslator.org/zh/yomitan2.png)

1. 初期化が完了するのを待ち、yomitanを設定します。

   >[!WARNING]
   >プラグインを追加しても認識されない場合があります。ソフトウェアを一旦閉じて再度開くと認識されることがあります。
   
   ![img](https://image.lunatranslator.org/en/yomitan4.png)

1. 最終的な効果

   > [!TIP]
   > デフォルトでは、メインウィンドウはテキストや翻訳内容に応じて自動的にサイズが調整されます。これにより、Yomitanのウィンドウサイズも変更されます。
   >
   > **表示設定** → **インターフェース設定** → **メインインターフェース** にて、**高さの自動調整** のチェックを外してください。
   >
   > ![img](https://image.lunatranslator.org/en/yomi9.png)

   ![img](https://image.lunatranslator.org/zh/yomitan5.png)

1. メインインターフェースに加えて、履歴テキストウィンドウでもブラウザ拡張機能を使用できますが、リソース節約のためデフォルトでは有効になりません

   ![img](https://image.lunatranslator.org/zh/yomitan7.png)

   ![img](https://image.lunatranslator.org/zh/yomitan6.png)

   ![img](https://image.lunatranslator.org/zh/yomitan8.png)
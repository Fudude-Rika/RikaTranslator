# ソフトウェアダウンロード & よくある質問

## ダウンロード

| OS | 64ビット |
| - | - |
| Windows 11 & 10(1803+) | <downloadbtn href="https://lunatranslator.org/Resource/DownloadLuna/x64_win10?doc=1"/> |

::: details 旧版OS互換版  

>[!WARNING]  
これらのバージョンは性能が劣り、動作が不安定で、一部の機能や特徴が欠けており、ウイルス対策ソフトに誤検知されやすくなっています。特別な必要がない場合は使用しないことをお勧めします。

| OS | 32ビット | 64ビット |
| - | - | - |
| Windows 7 以降 | | <downloadbtn href="https://lunatranslator.org/Resource/DownloadLuna/x64_win7?doc=1"/> |
| Windows XP 以降 | <downloadbtn href="https://lunatranslator.org/Resource/DownloadLuna/x86_winxp?doc=1"/> | |

:::

## コミュニティ & 作者を支援 {#anchor-support}

ソフトウェアの使用中に問題が発生した場合は、[Discord](https://discord.com/invite/ErtDwVeAbB)に参加してください。

<a href="https://discord.gg/invite/ErtDwVeAbB"><img src="https://img.shields.io/discord/1262692128031772733?style=for-the-badge&logo=discord&logoColor=white&label=Discord&color=5865F2" alt="Discord"></a>


ソフトウェアのメンテナンスは容易ではありません。もしこのソフトウェアが役に立ったと感じていただけたら、[patreon](https://patreon.com/HIllya51)を通じてサポートしていただけると嬉しいです。皆様のサポートがソフトウェアの長期的なメンテナンスの力になります。ありがとうございます～

<a href="https://patreon.com/HIllya51" target='_blank'><img width="200" src="/become_a_patron_4x1_black_logo_white_text_on_coral.svg"></a>

## 起動 & 更新

ダウンロード後、任意のディレクトリにファイルを解凍します。

::: warning
ただし、**C:\Program Files** などの特別なパスにソフトウェアを配置しないでください。そうしないと、管理者権限があっても、構成やキャッシュファイルを保存したり、プログラムを実行したりできない可能性があります。
:::

| LunaTranslator.exe | LunaTranslator_admin.exe | LunaTranslator_debug.bat |
| - | - | - |
| 通常モードで起動します | 管理者権限で起動します。一部のゲームのフックには管理者権限が必要です。必要な場合のみ使用し、通常は通常モードで起動してください | コマンドラインウィンドウを表示します |

デフォルトでは自動的に更新されます。自動更新に失敗した場合、手動で更新できます。

手動で更新したい場合は、新しいバージョンをダウンロードし、前のディレクトリに解凍して上書きするだけです。

削除して再ダウンロードしたい場合は、userconfigフォルダを削除しないように注意してください。削除すると以前の設定が失われます！！！

## よくあるエラー {#anchor-commonerrors}

### 重要なコンポーネントが見つからない / Missing embedded Python3

::: danger
時々、ウイルス対策ソフトによってフラグが立てられることがあります。信頼リストに追加し、再度ダウンロードして解凍してください。
:::

![img](https://image.lunatranslator.org/zh/cantstart/2.jpg) 

![img](https://image.lunatranslator.org/zh/missingpython.png) 

解決方法：ウイルス対策ソフトを無効にする。無効にできない場合（例：Windows Defender）、信頼リストに追加してから再ダウンロードする。

注：ゲームテキストのHOOK抽出を実現するために、Dllをゲームに注入する必要があります。LunaSubprocess32.exe/LunaHost32.dllなどのファイルはこれを実装しているため、特にウイルスと見なされやすいです。ソフトウェアは現在[Github Actions](https://github.com/HIllya51/LunaTranslator/actions)によって自動的にビルドされています。Githubサーバーが感染していない限り、ウイルスが含まれることはないため、信頼リストに安全に追加できます。

::: details Windows Defenderの場合、方法は：「ウイルスと脅威の防止」->「除外」->「除外の追加または削除」->「除外の追加」->「フォルダー」、Lunaのフォルダーを追加します
![img](https://image.lunatranslator.org/zh/cantstart/4.png) 
![img](https://image.lunatranslator.org/zh/cantstart/3.png) 
::: 

### DLLがゲームに注入されるのを待っています… {#anchor-waitdll}

解決方法は上記と同じです。

### Error/FileNotFoundError

事前に信頼リストに追加していない場合、ソフトウェアがしばらく動作した後で必要なコンポーネントがウイルス対策ソフトに削除される可能性があります。その後、HOOKモードでプロセスを選択した際にこのエラーが発生します。解決方法は上記と同じです。

<img src="https://image.lunatranslator.org/zh/notfound.png" width=400>

### Error/PermissionError

ソフトウェアが`C:\Program Files`などの特殊なフォルダーに配置されている場合、正常に動作しない可能性があります。

<img src="https://image.lunatranslator.org/zh/cantstart/6.png" width=400>

## ChangeLog

::: details
<RemoteMarkdown />

:::
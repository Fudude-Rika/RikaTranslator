# 音声合成エンジン

::: tabs

== Windows TTS

#### SAPI

Windows 7以降では、システムの言語設定で、言語の音声合成パッケージを追加すれば使用できます。

#### 自然音声

Windows 10およびWindows 11では、Windowsナチュラルボイスをご利用いただけます。

>[!WARNING]
>Microsoftが新しいバージョンの言語パックの暗号化方式を変更したため、システムにインストールされている言語パックとダウンロードした新しいバージョンの言語パックは直接使用できません。使用するには[この記事](https://www.patreon.com/posts/fixing-use-of-on-133196054)をご参照ください。

Windows 11では、言語の音声合成パッケージの他に、`アクセシビリティ` -> `ナレーター` -> `自然な音声の追加` から、より高品質な自然な音声を追加することもできます。

Windows 10上で、またはシステムに追加したくない場合、[NVDA 中文站](https://www.nvdacn.com/index.php/tts.html)から`Microsoft Natural Voice（自然音声）`をダウンロードし、ソフトウェアディレクトリに解凍することで自然音声を使用できます。

Windows 10では、システムに必要なランタイムおよび認識モデルが不足しています。または、Windows 11のバージョンが低すぎるため、システムに組み込まれているランタイムのバージョンが低くなっています。音声パックのダウンロードに加えて、[自然音声ランタイム](https://lunatranslator.org/Resource/microsoft.cognitiveservices.speech)を追加でダウンロードし、ソフトウェアディレクトリに解凍する必要があります。

== VoiceRoid/A.I.VOICE

#### A.I.VOICE

公式サイトから[A.I.VOICE](https://aivoice.jp/member/downloads/aivoice)または[A.I.VOICE2](https://aivoice.jp/member/downloads/aivoice2)をダウンロードしてインストールすれば使用できます。

#### VoiceRoid

リソースダウンロードで関連リソースをダウンロードし、解凍先のパスを選択するだけです。

ただし、**追加音源**については、まず任意の**統合パック**をダウンロードし、それを統合パック内に解凍しないと使用できません。なぜなら、統合パックには比較的人気のある音源と必要なランタイムが含まれており、追加音源のみをダウンロードするとVoiceRoidのランタイムが不足するためです。

== VOICEVOX

[VOICEVOX](https://github.com/VOICEVOX/voicevox/releases)をダウンロードして実行する必要があります。

デフォルトのポート番号はVOICEVOXのデフォルトポート番号と同じです。双方の設定を変更しなければ、実行してアクティベートするだけで使用できます。

== GPT-SoVITS

`API version`のv2はGPT-SoVITSのAPIインターフェースのバージョンであり、モデルのバージョンではありません。通常、デフォルトのv2を使用すれば十分です。

その他のパラメータには、よく使われる少数のパラメータのみが追加されています。他のパラメータが必要な場合は、自分で追加できます。

:::